Collective Deck - Netlify-ready project. Upload to Netlify Drop or push to GitHub and connect.
Spectator: /spectator/
Magician: /magician/
Function: /.netlify/functions/prediction
Timeout: 20 seconds (server-side and client-side).