let currentPrediction = null;
let timeout = null;

exports.handler = async (event, context) => {
  const { httpMethod, body } = event;

  if (httpMethod === "POST") {
    try {
      const data = JSON.parse(body);
      currentPrediction = data.image || null;

      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => {
        currentPrediction = null;
      }, 20000); // Clear after 20 seconds

      return {
        statusCode: 200,
        body: JSON.stringify({ message: "Card revealed!" }),
      };
    } catch (err) {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
    }
  }

  if (httpMethod === "GET") {
    return {
      statusCode: 200,
      body: JSON.stringify({ image: currentPrediction }),
    };
  }

  return { statusCode: 405, body: "Method Not Allowed" };
};
